package com.example.coursemanagementsystem;

import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.function.Predicate;

public class TeacherMainPageController {
    @FXML
    private TableColumn<Course, String> column_desc;
    @FXML
    private TableColumn<Course, String> column_title;
    @FXML
    private TableColumn<Course, String> column_type;
    @FXML
    private TableView<Course> tableView;
    @FXML
    private Rectangle rectangle;
    @FXML
    private Label userName;
    @FXML
    private AnchorPane rootAnchor;

    @FXML
    private VBox menuContent;
    private String teacherId;
    ObservableList<Course> listM;
    private FilteredList<Course> filteredCourses;

    @FXML
    private TextField search;
    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;

        column_title.setCellValueFactory(new PropertyValueFactory<>("courseTitle"));
        column_desc.setCellValueFactory(new PropertyValueFactory<>("description"));
        column_type.setCellValueFactory(new PropertyValueFactory<>("courseType"));

        displayAllCourses();
        setupSearch();
    }

    private void displayAllCourses() {
        listM = UserDAO.getAllCourses(teacherId);
        filteredCourses = new FilteredList<>(listM, e -> true);
        SortedList<Course> sortedCourses = new SortedList<>(filteredCourses);
        tableView.setItems(sortedCourses);
    }

    private void setupSearch() {
        search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredCourses.setPredicate(createPredicate(newValue));
        });
    }

    private Predicate<Course> createPredicate(String searchText) {
        return course -> {

            if (searchText == null || searchText.isEmpty()) {
                return true;
            }

            String lowerCaseSearchText = searchText.toLowerCase();

            return course.getCourseTitle().toLowerCase().contains(lowerCaseSearchText)
                    || course.getDescription().toLowerCase().contains(lowerCaseSearchText)
                    || course.getCourseType().toLowerCase().contains(lowerCaseSearchText);
        };
    }
    public void setUsername(String username) {
        userName.setText("" + username);
    }
    @FXML
    public void clickMenu(){
        rectangle.setVisible(true);
        menuContent.setVisible(!menuContent.isVisible());
    }
    private String email;

    public void setEmail(String email) {
        this.email = email;
    }
    private String pass;

    public void setPassword(String password) {
        this.pass = password;
    }

    @FXML
    public void clickBack(){
        rectangle.setVisible(false);
        menuContent.setVisible(false);
    }
    @FXML
    private void onClickDelete() {
        Course selectedCourse = tableView.getSelectionModel().getSelectedItem();

        if (selectedCourse != null) {
            String title = selectedCourse.getCourseTitle();
            String description = selectedCourse.getDescription();

            UserDAO.deleteCourseByTitleAndDescription(title, description);

            displayAllCourses();
        } else {
            System.out.println("Something Wrong");
        }
    }


    @FXML
    private void switchToSignInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent signInPageRoot = loader.load();
            HelloController mainPageController = loader.getController();
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onClickCreate(){
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CreateCourse.fxml"));
            Parent createCoursePageRoot = loader.load();
            CreateCourseController mainPageController = loader.getController();
            mainPageController.setUsername(userName.getText());
            mainPageController.setEmail(email);
            System.out.println("E:   " + email);
            mainPageController.setPassword(pass);
            mainPageController.setTeacherId(this.teacherId);

            Scene mainPageScene = new Scene(createCoursePageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void switchToProfilePage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("profile.fxml"));
            Parent signInPageRoot = loader.load();
            ProfileController mainPageController = loader.getController();
            mainPageController.setEmail(email);
            System.out.println("E:   " + email);
            mainPageController.setPassword(pass);
            mainPageController.setTeacherId(this.teacherId);
            mainPageController.setUsername(userName.getText());
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
