package com.example.coursemanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.ArrayList;

public class UserDAO{
    private static Connection conn;

    public static Connection getConnection() {
        String url = "jdbc:postgresql://localhost/postgres";
        String username = "postgres";
        String pass = "1234";

        try {
            conn = DriverManager.getConnection(url, username, pass);
            System.out.println("Database successfully connected");
            return conn;
        } catch (SQLException e) {
            System.out.println(e.toString());
            throw new RuntimeException("Error connecting to the database", e);
        }
    }

    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Database connection closed");
            }
        } catch (SQLException e) {
            System.out.println("Error closing database connection: " + e.toString());
        }
    }

    public String getUserNameByEmail(String email) {
        String query = "SELECT t_name FROM teacher WHERE t_email = ? UNION SELECT name FROM student WHERE s_email = ?";

        try (Connection con = getConnection();
             PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, email);
            statement.setString(2, email);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("t_name");
            } else {
                return null; // Handle the case where no user is found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error retrieving user name from the database", e);
        }
    }

    public static String getCourseCode(String courseTitle, String description) {
        String query = "SELECT course_code FROM course WHERE course_title = ? AND description = ?";

        try (Connection con = getConnection();
             PreparedStatement statement = con.prepareStatement(query)) {

            statement.setString(1, courseTitle);
            statement.setString(2, description);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("course_code");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error retrieving course code from the database", e);
        }

        return null;
    }
    public void insertCourse(String courseTitle, String description, String courseType, String teacher_id) {
        String insertCourseQuery = "INSERT INTO course(teacher_id, course_title, description, c_type, start_time) VALUES (?, ?, ?, ?, ?)";
        String insertTimeSlotQuery = "INSERT INTO time_slot(start_time) VALUES (?)";

        try (Connection con = getConnection();
             PreparedStatement insertCourseStatement = con.prepareStatement(insertCourseQuery);
             PreparedStatement insertTimeSlotStatement = con.prepareStatement(insertTimeSlotQuery)) {

            con.setAutoCommit(false);

            LocalDateTime currentTime = LocalDateTime.now();
            Timestamp startTime = Timestamp.valueOf(currentTime);

            insertTimeSlotStatement.setTimestamp(1, startTime);
            insertTimeSlotStatement.executeUpdate();

            if (!courseTypeExists(con, courseType)) {
                System.out.println("Error: Course type does not exist in course_type table");
                return;
            }

            insertCourseStatement.setString(1, teacher_id);
            insertCourseStatement.setString(2, courseTitle);
            insertCourseStatement.setString(3, description);
            insertCourseStatement.setString(4, courseType);
            insertCourseStatement.setTimestamp(5, startTime);
            insertCourseStatement.executeUpdate();

            con.commit();
            System.out.println("Course successfully inserted into the database");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error inserting course into the database", e);
        }
    }

    private boolean courseTypeExists(Connection con, String courseType) throws SQLException {
        String query = "SELECT 1 FROM course_type WHERE c_type = ?";
        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, courseType);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public static ObservableList<Course> getAllCourses(String teacher_id) {
        Connection con = getConnection();
        ObservableList<Course> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT course_title, description, c_type FROM course WHERE teacher_id = ?");
            System.out.println("teacher_id: " + teacher_id);
            ps.setString(1, teacher_id);
            ResultSet rs = ps.executeQuery();
            SQLWarning warning = rs.getWarnings();
            while (warning != null) {
                System.err.println("SQL Warning: " + warning.getMessage());
                warning = warning.getNextWarning();
            }
            while (rs.next()) {
                list.add(new Course(rs.getString("course_title"), rs.getString("description"), rs.getString("c_type")));
            }
            System.out.println("Number of courses: " + list.size());
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
        return list;
    }

    public static ObservableList<Course> reccomendedCourses(String studentId) {
        Connection con = getConnection();
        ObservableList<Course> list = FXCollections.observableArrayList();

        try {
            String query = "SELECT course_title, description, c_type " +
                    "FROM course c " +
                    "WHERE NOT EXISTS (" +
                    "    SELECT 1 " +
                    "    FROM takes t " +
                    "    WHERE t.course_code = c.course_code " +
                    "    AND t.id = ?" +
                    ")";

            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, studentId);

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    list.add(new Course(rs.getString("course_title"), rs.getString("description"), rs.getString("c_type")));
                }

                System.out.println("Number of recommended courses for student " + studentId + ": " + list.size());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return list;
    }

    public static void deleteCourseByTitleAndDescription(String title, String description) {
        String deleteCourseQuery = "DELETE FROM course WHERE course_title = ? AND description = ?";

        try (Connection con = getConnection();
             PreparedStatement deleteCourseStatement = con.prepareStatement(deleteCourseQuery)) {

            deleteCourseStatement.setString(1, title);
            deleteCourseStatement.setString(2, description);

            int rowsAffected = deleteCourseStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Course successfully deleted from the database");
            } else {
                System.out.println("Course not found or deletion failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error deleting course from the database", e);
        }
    }

    public static void deleteCourseFromTakes(String studentId, String courseCode) {
        String deleteCourseQuery = "DELETE FROM takes WHERE id = ? AND course_code = ?";

        try (Connection con = getConnection();
             PreparedStatement deleteCourseStatement = con.prepareStatement(deleteCourseQuery)) {

            deleteCourseStatement.setString(1, studentId);
            deleteCourseStatement.setString(2, courseCode);

            int rowsAffected = deleteCourseStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Course successfully deleted from the 'takes' table");
            } else {
                System.out.println("Course not found in the 'takes' table or deletion failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error deleting course from the 'takes' table", e);
        }
    }

    public static String getStudentIdByEmail(String email) {
        String query = "SELECT id FROM student WHERE s_email = ?";

        try (Connection con = getConnection();
             PreparedStatement statement = con.prepareStatement(query)) {

            statement.setString(1, email);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error retrieving student ID from the database", e);
        }

        return null;
    }

    public static ObservableList<Course> takes(String studentId) {
        Connection con = getConnection();
        ObservableList<Course> list = FXCollections.observableArrayList();

        try {
            String query = "SELECT c.course_title, c.description, c.c_type " +
                    "FROM course c " +
                    "WHERE EXISTS (" +
                    "    SELECT 1 " +
                    "    FROM takes t " +
                    "    WHERE t.course_code = c.course_code " +
                    "    AND t.id = ?" +
                    ")";

            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, studentId);

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    list.add(new Course(rs.getString("course_title"), rs.getString("description"), rs.getString("c_type")));
                }

                System.out.println("Number of courses for student " + studentId + ": " + list.size());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return list;
    }

    public static void takeCourse(String studentId, String courseCode) {
        Connection con = getConnection();

        try {
            String query = "INSERT INTO takes (id, course_code) VALUES (?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, studentId);
                ps.setString(2, courseCode);

                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Course successfully taken!");
                } else {
                    System.out.println("Failed to take the course.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    public boolean updateStudentInfo(String studentId, String name, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = getConnection();

            String studentUpdateQuery = "UPDATE student SET name=?, s_password=? WHERE id=?";
            preparedStatement = connection.prepareStatement(studentUpdateQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, studentId);

            int studentUpdateCount = preparedStatement.executeUpdate();

            return studentUpdateCount > 0; // Return true if the update was successful

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return false;
    }

    public boolean updateTeacherInfo(String teacherId, String name, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = getConnection();

            String teacherUpdateQuery = "UPDATE teacher SET t_name=?, t_password=? WHERE teacher_id=?";
            preparedStatement = connection.prepareStatement(teacherUpdateQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, teacherId);

            int teacherUpdateCount = preparedStatement.executeUpdate();

            return teacherUpdateCount > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return false;
    }
}
