package com.example.coursemanagementsystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class SignUpController {

    @FXML
    private RadioButton teacher;

    @FXML
    private Label error;

    @FXML
    private RadioButton student;

    @FXML
    private TextField name, e_mail;

    @FXML
    private PasswordField password;

    @FXML
    private AnchorPane rootAnchor;

    private String username;

    private ToggleGroup user = new ToggleGroup();

    @FXML
    private void checkingSignUp() {
        if (!e_mail.getText().isEmpty() && !password.getText().isEmpty() && !name.getText().isEmpty()) {
            signUpButtonAction();
        } else {
            error.setText("Please enter non-empty values for e-mail, password, and name");
        }
    }

    private void switchToMainPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainpage.fxml"));
            Parent mainPageRoot = loader.load();
            MainPageController mainPageController = loader.getController();
            String email = e_mail.getText();
            String studentId = UserDAO.getStudentIdByEmail(email);

            if (studentId != null) {
                mainPageController.setId(studentId);
                mainPageController.setUsername(username);
                mainPageController.setEmail(e_mail.getText());
                mainPageController.setPassword(password.getText());
                Scene mainPageScene = new Scene(mainPageRoot);
                Stage stage = (Stage) rootAnchor.getScene().getWindow();
                stage.setScene(mainPageScene);
                stage.show();
            } else {
                error.setText("Student ID not found for the given email: " + email);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void signUpButtonAction() {
        UserDAO userDAO = new UserDAO();
        Connection con = userDAO.getConnection();

        try {
            String queryCheckExistence;
            String queryInsert;

            if (teacher.isSelected()) {
                queryCheckExistence = "SELECT * FROM teacher WHERE t_email = ?";
                queryInsert = "INSERT INTO teacher (t_name, t_email, t_password) VALUES (?, ?, ?)";
            } else {
                queryCheckExistence = "SELECT * FROM student WHERE s_email = ?";
                queryInsert = "INSERT INTO student (name, s_email, s_password) VALUES (?, ?, ?)";
            }

            try (PreparedStatement checkExistenceStatement = con.prepareStatement(queryCheckExistence)) {
                checkExistenceStatement.setString(1, e_mail.getText());
                try (ResultSet resultSet = checkExistenceStatement.executeQuery()) {
                    if (resultSet.next()) {
                        error.setText("Account with this e-mail already exists!");
                        user.selectToggle(null);
                        name.clear();
                        e_mail.clear();
                        password.clear();
                        return;
                    }
                }
            }

            try (PreparedStatement insertStatement = con.prepareStatement(queryInsert)) {
                insertStatement.setString(1, name.getText());
                insertStatement.setString(2, e_mail.getText());
                insertStatement.setString(3, password.getText());

                insertStatement.executeUpdate();
                username = name.getText();

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Welcome!");
                alert.setHeaderText("You signed up successfully!");
                alert.setContentText("Welcome to our Skillify Course Management! Knowledge for Tomorrow, Skills for Today.");
                alert.showAndWait();
                if (student.isSelected()) {
                    switchToMainPage();
                } else {
                    switchToTeacherPage();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void switchToTeacherPage() {
        try {
            String name = new UserDAO().getUserNameByEmail(e_mail.getText());
            String email = e_mail.getText();

            UserDAO dao = new UserDAO();
            Connection con = dao.getConnection();

            String query = "SELECT teacher_id FROM teacher WHERE t_email = ?";
            try (PreparedStatement statement = con.prepareStatement(query)) {
                statement.setString(1, email);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String teacherId = resultSet.getString("teacher_id");

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("teachermainpage.fxml"));
                        Parent teacherMainPageRoot = loader.load();
                        TeacherMainPageController teacherMainPageController = loader.getController();
                        teacherMainPageController.setTeacherId(teacherId);
                        teacherMainPageController.setEmail(e_mail.getText());
                        System.out.println("Email is " + e_mail.getText());
                        teacherMainPageController.setPassword(password.getText());
                        teacherMainPageController.setUsername(name);

                        Scene teacherMainPageScene = new Scene(teacherMainPageRoot);
                        Stage stage = (Stage) rootAnchor.getScene().getWindow();
                        stage.setScene(teacherMainPageScene);
                        stage.show();
                    } else {
                        System.out.println("Teacher not found for email: " + email);
                    }
                }
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void switchToSignInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent signInPageRoot = loader.load();
            HelloController mainPageController = loader.getController();
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
