package com.example.coursemanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfileController {

    @FXML
    private AnchorPane rootAnchor;

    @FXML
    private VBox menuContent;

    @FXML
    private Rectangle rectangle;

    @FXML
    private Label massage;

    @FXML
    private TextField e_mail, name;

    @FXML
    private PasswordField password;

    @FXML
    private Label userName;

    private String teacherId, id;

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUsername(String username) {
        userName.setText(" " + username);
        name.setText(username);
    }

    public void setEmail(String email) {
        e_mail.setText(email);
    }

    public void setPassword(String pass) {
        password.setText(pass);
    }

    @FXML
    public void clickMenu() {
        rectangle.setVisible(true);
        menuContent.setVisible(!menuContent.isVisible());
    }

    @FXML
    public void clickBack() {
        rectangle.setVisible(false);
        menuContent.setVisible(false);
    }

    @FXML
    private void switchToSignInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent signInPageRoot = loader.load();
            HelloController mainPageController = loader.getController();
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void updateUserInformation() {
        if ((id != null && id.startsWith("S")) || (teacherId != null && teacherId.startsWith("T"))) {
            UserDAO userDAO = new UserDAO();

            if (name.getText() != null && password.getText() != null) {
                if (id != null && id.startsWith("S")) {
                    userDAO.updateStudentInfo(id, name.getText(), password.getText());
                } else if (teacherId != null && teacherId.startsWith("T")) {
                    userDAO.updateTeacherInfo(teacherId, name.getText(), password.getText());
                }
                massage.setText("Changes saved!");
                userName.setText(name.getText());
            } else {
                massage.setText("Password or name must not be empty!");
            }
        } else {
            massage.setText("Invalid user ID or teacher ID.");
        }
    }

    @FXML
    private void goToDashboard() {
        if (id != null && id.startsWith("S")) {
            switchToMainPage();
        } else if (teacherId != null && teacherId.startsWith("T")) {
            switchToTeacherPage();
        } else {
            System.out.println("Invalid user or teacher ID.");
        }
    }

    private void switchToMainPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainpage.fxml"));
            Parent mainPageRoot = loader.load();
            MainPageController mainPageController = loader.getController();
            String email = e_mail.getText();
            String studentId = UserDAO.getStudentIdByEmail(email);

            if (studentId != null) {
                mainPageController.setId(studentId);
                mainPageController.setUsername(userName.getText());
                mainPageController.setEmail(e_mail.getText());
                mainPageController.setPassword(password.getText());
                Scene mainPageScene = new Scene(mainPageRoot);
                Stage stage = (Stage) rootAnchor.getScene().getWindow();
                stage.setScene(mainPageScene);
                stage.show();
            } else {
                System.out.println("Student ID not found for the given email: " + email);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void switchToTeacherPage() {
        try {
            String name = new UserDAO().getUserNameByEmail(e_mail.getText());
            String email = e_mail.getText();

            UserDAO dao = new UserDAO();
            Connection con = dao.getConnection();

            String query = "SELECT teacher_id FROM teacher WHERE t_email = ?";
            try (PreparedStatement statement = con.prepareStatement(query)) {
                statement.setString(1, email);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String teacherId = resultSet.getString("teacher_id");

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("teachermainpage.fxml"));
                        Parent teacherMainPageRoot = loader.load();
                        TeacherMainPageController teacherMainPageController = loader.getController();
                        teacherMainPageController.setTeacherId(teacherId);
                        teacherMainPageController.setEmail(e_mail.getText());
                        teacherMainPageController.setPassword(password.getText());
                        teacherMainPageController.setUsername(name);

                        Scene teacherMainPageScene = new Scene(teacherMainPageRoot);
                        Stage stage = (Stage) rootAnchor.getScene().getWindow();
                        stage.setScene(teacherMainPageScene);
                        stage.show();
                    } else {
                        System.out.println("Teacher not found for email: " + email);
                    }
                }
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}
