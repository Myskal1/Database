package com.example.coursemanagementsystem;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;

public class CreateCourseController {

    @FXML
    private TextField title;
    @FXML
    private TextField description;
    @FXML
    private ChoiceBox<String> box;
    @FXML
    private AnchorPane rootAnchor;
    @FXML
    private Label error;
    @FXML
    private Label userName;
    @FXML
    private VBox menuContent;
    @FXML
    private Rectangle rectangle;

    private String teacherId;
    private String email;
    private String pass;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.pass = password;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    @FXML
    public void clickMenu() {
        menuContent.setVisible(!menuContent.isVisible());
        rectangle.setVisible(true);
    }

    @FXML
    public void clickBack() {
        rectangle.setVisible(false);
        menuContent.setVisible(false);
    }

    @FXML
    private void switchToSignInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent signInPageRoot = loader.load();
            HelloController mainPageController = loader.getController();
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setUsername(String username) {
        userName.setText(" " + username);
    }

    @FXML
    public void initialize() {
        box.setItems(FXCollections.observableArrayList("Language Course", "IT Course", "Media Course", "School Subjects"));
        box.setOnAction(event -> {
            String selectedOption = box.getValue();
        });
    }

    @FXML
    protected void onClickCreate() {
        if (!title.getText().isBlank() && !description.getText().isBlank() && box.getValue() != null && !box.getValue().isBlank()) {
            UserDAO userDAO = new UserDAO();
            userDAO.insertCourse(title.getText(), description.getText(), box.getValue(), teacherId);
            switchToTeacherPage();
        } else {
            error.setText("Please enter title, description, type, and code!");
        }
    }

    @FXML
    private void switchToTeacherPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("teachermainpage.fxml"));
            Parent teacherMainPageRoot = loader.load();
            TeacherMainPageController teacherMainPageController = loader.getController();
            teacherMainPageController.setEmail(this.email);
            teacherMainPageController.setPassword(this.pass);
            teacherMainPageController.setTeacherId(teacherId);
            teacherMainPageController.setUsername(userName.getText());
            Scene teacherMainPageScene = new Scene(teacherMainPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(teacherMainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void switchToProfilePage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("profile.fxml"));
            Parent signInPageRoot = loader.load();
            ProfileController mainPageController = loader.getController();
            mainPageController.setUsername(userName.getText());
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
