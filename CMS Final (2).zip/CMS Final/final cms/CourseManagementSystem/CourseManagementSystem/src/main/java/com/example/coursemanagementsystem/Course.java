package com.example.coursemanagementsystem;

import javafx.scene.control.Button;

import java.time.LocalDateTime;

public class Course {
    private Button button_action;
    private String courseTitle;
    private String description;
    private String courseType;
    public Button getButton_action() {
        return button_action;
    }

    public void setButton_action(Button button_action) {
        this.button_action = button_action;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public String getDescription() {
        return description;
    }

    public String getCourseType() {
        return courseType;
    }

    public Course(String courseTitle, String description, String courseType) {
        this.courseTitle = courseTitle;
        this.description = description;
        this.courseType = courseType;
    }
}
