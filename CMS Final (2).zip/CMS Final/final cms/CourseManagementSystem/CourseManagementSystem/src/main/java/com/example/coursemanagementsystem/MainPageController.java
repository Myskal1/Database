package com.example.coursemanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.function.Predicate;

public class MainPageController {

    @FXML
    private TableColumn<Course, String> column_title, column_title1, column_type, column_type1;

    @FXML
    private TableView<Course> courseTableView, courseTableView1;

    @FXML
    private TableColumn<Course, String> description, description1;

    @FXML
    private TextField search;

    @FXML
    private AnchorPane rootAnchor;

    @FXML
    private VBox menuContent;

    @FXML
    private Rectangle rectangle;

    private String id, email, pass;

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.pass = password;
        System.out.println(this.pass);
    }

    public void setId(String id) {
        this.id = id;
        displayRecommendedCourses();
        displayTakenCourses();
        setupSearch();
    }

    @FXML
    private void initialize() {
        column_title.setCellValueFactory(new PropertyValueFactory<>("courseTitle"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        column_type.setCellValueFactory(new PropertyValueFactory<>("courseType"));
        column_title1.setCellValueFactory(new PropertyValueFactory<>("courseTitle"));
        description1.setCellValueFactory(new PropertyValueFactory<>("description"));
        column_type1.setCellValueFactory(new PropertyValueFactory<>("courseType"));
    }

    private void setupSearch() {
        search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredTakenCourses.setPredicate(createPredicate(newValue));
            filteredRecommendedCourses.setPredicate(createPredicate(newValue));
        });
    }

    private Predicate<Course> createPredicate(String searchText) {
        return course -> {
            if (searchText == null || searchText.isEmpty()) {
                return true;
            }
            String lowerCaseSearchText = searchText.toLowerCase();

            return course.getCourseTitle().toLowerCase().contains(lowerCaseSearchText)
                    || course.getDescription().toLowerCase().contains(lowerCaseSearchText)
                    || course.getCourseType().toLowerCase().contains(lowerCaseSearchText);
        };
    }

    @FXML
    private void onClickTake() {
        Course selectedCourse = courseTableView.getSelectionModel().getSelectedItem();

        if (selectedCourse != null) {
            String courseTitle = selectedCourse.getCourseTitle();
            String description = selectedCourse.getDescription();

            String courseCode = UserDAO.getCourseCode(courseTitle, description);

            if (courseCode != null) {
                UserDAO.takeCourse(id, courseCode);

                displayRecommendedCourses();
                displayTakenCourses();
            } else {
                System.out.println("Course code not found for the selected course.");
            }
        } else {
            System.out.println("Please select a course.");
        }
    }

    @FXML
    private void onClickDelete() {
        Course selectedCourse = courseTableView1.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            String courseCode = UserDAO.getCourseCode(selectedCourse.getCourseTitle(), selectedCourse.getDescription());
            if (courseCode != null) {
                UserDAO.deleteCourseFromTakes(id, courseCode);
                displayRecommendedCourses();
                displayTakenCourses();
            }
        } else {
            System.out.println("Something Wrong");
        }
    }

    private FilteredList<Course> filteredRecommendedCourses, filteredTakenCourses;

    private void displayRecommendedCourses() {
        ObservableList<Course> recommendedCourses = UserDAO.reccomendedCourses(id);
        filteredRecommendedCourses = new FilteredList<>(recommendedCourses, e -> true);
        SortedList<Course> sortedCourses = new SortedList<>(filteredRecommendedCourses);
        courseTableView.setItems(sortedCourses);
    }

    private void displayTakenCourses() {
        ObservableList<Course> takenCourses = UserDAO.takes(id);
        filteredTakenCourses = new FilteredList<>(takenCourses, e -> true);
        SortedList<Course> sortedCourses = new SortedList<>(filteredTakenCourses);
        courseTableView1.setItems(sortedCourses);
    }

    @FXML
    public void clickMenu() {
        rectangle.setVisible(true);
        menuContent.setVisible(!menuContent.isVisible());
    }

    @FXML
    public void clickBack() {
        rectangle.setVisible(false);
        menuContent.setVisible(false);
    }

    @FXML
    private void switchToSignInPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent signInPageRoot = loader.load();
            HelloController mainPageController = loader.getController();
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private Label userName;

    public void setUsername(String username) {
        userName.setText(" " + username);
    }

    @FXML
    private void switchToProfilePage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("profile.fxml"));
            Parent signInPageRoot = loader.load();
            ProfileController mainPageController = loader.getController();
            mainPageController.setUsername(userName.getText());
            mainPageController.setEmail(this.email);
            mainPageController.setPassword(this.pass);
            mainPageController.setId(this.id);
            Scene mainPageScene = new Scene(signInPageRoot);
            Stage stage = (Stage) rootAnchor.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
