package com.example.coursemanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class HelloController {
    @FXML
    private AnchorPane rootAnchorPane;
    @FXML
    private Button SignIn;
    @FXML
    private Label error;
    @FXML
    private Text exit;
    @FXML
    private Button SignUp;
    @FXML
    private TextField e_mail;
    @FXML
    private PasswordField password;

    @FXML
    protected void onClickSignIn() {
        if(e_mail.getText().isBlank() == false && password.getText().isBlank() == false){
            validateLogin();
        } else{
            error.setText("Please enter username and password!");
        }

    }
    public void validateLogin(){
        UserDAO dao = new UserDAO();
        Connection con = dao.getConnection();
        String verifyLogin;
        if(isStudent(e_mail.getText())){
            verifyLogin = "select count(1)from student s where s_email = '" + e_mail.getText() + "' and  s_password = '" + password.getText() + "'";
        }else{
            verifyLogin = "select count(1)from teacher s where t_email = '" + e_mail.getText() + "' and  t_password = '" + password.getText() + "'";
        }

        try {
            Statement st = con.createStatement();
            ResultSet queryResult = st.executeQuery(verifyLogin);

            while(queryResult.next()){
                 if (queryResult.getInt(1) == 1){
                     if (isStudent(e_mail.getText())) {
                         switchToMainPage();
                     } else if (isTeacher(e_mail.getText())) {
                         switchToTeacherPage();
                     }
                 } else {
                     error.setText("Invalid login or password. Please, try again!");
                     password.clear();
                 }
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    private String getStudentIdByEmail(String email) {
        return new UserDAO().getStudentIdByEmail(email);
    }

    @FXML
    private void switchToMainPage() {
        try {
            String name = new UserDAO().getUserNameByEmail(e_mail.getText());
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainpage.fxml"));
            Parent mainPageRoot = loader.load();
            MainPageController mainPageController = loader.getController();
            String studentId = getStudentIdByEmail(e_mail.getText());
            mainPageController.setUsername(name);
            mainPageController.setId(studentId);
            mainPageController.setEmail(e_mail.getText());
            mainPageController.setPassword(password.getText());
            Scene mainPageScene = new Scene(mainPageRoot);
            Stage stage = (Stage) rootAnchorPane.getScene().getWindow();
            stage.setScene(mainPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void switchToSignUpPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SignUp.fxml"));
            Parent signUpPageRoot = loader.load();
            SignUpController SignUpPageController = loader.getController();
            Scene signUpPageScene = new Scene(signUpPageRoot);
            Stage stage = (Stage) rootAnchorPane.getScene().getWindow();
            stage.setScene(signUpPageScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void switchToTeacherPage() {
        try {
            String name = new UserDAO().getUserNameByEmail(e_mail.getText());
            String email = e_mail.getText();

            UserDAO dao = new UserDAO();
            Connection con = dao.getConnection();

            String query = "SELECT teacher_id FROM teacher WHERE t_email = ?";
            try (PreparedStatement statement = con.prepareStatement(query)) {
                statement.setString(1, email);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String teacherId = resultSet.getString("teacher_id");

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("teachermainpage.fxml"));
                        Parent teacherMainPageRoot = loader.load();
                        TeacherMainPageController teacherMainPageController = loader.getController();
                        teacherMainPageController.setTeacherId(teacherId);
                        teacherMainPageController.setEmail(e_mail.getText());
                        teacherMainPageController.setPassword(password.getText());
                        teacherMainPageController.setUsername(name);

                        Scene teacherMainPageScene = new Scene(teacherMainPageRoot);
                        Stage stage = (Stage) rootAnchorPane.getScene().getWindow();
                        stage.setScene(teacherMainPageScene);
                        stage.show();
                    } else {
                        System.out.println("Teacher not found for email: " + email);
                    }
                }
            }
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }


    private boolean isStudent(String email) {
        UserDAO dao = new UserDAO();
        Connection con = dao.getConnection();
        String query = "SELECT COUNT(1) FROM student WHERE s_email = ?";

        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private boolean isTeacher(String email) {
        UserDAO dao = new UserDAO();
        Connection con = dao.getConnection();
        String query = "SELECT COUNT(1) FROM teacher WHERE t_email = ?";

        try (PreparedStatement statement = con.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next() && resultSet.getInt(1) == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}